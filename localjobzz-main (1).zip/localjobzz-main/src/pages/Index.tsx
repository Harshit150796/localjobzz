
import HomePage from './Home';

const Index = () => {
  return <HomePage />;
};

export default Index;
